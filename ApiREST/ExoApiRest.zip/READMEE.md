thank you for the correction.

Je n'ai pas suivi le maniere d'ecrire la requete presentee dans le cours. J'ai utilise celle presente dans la documentation: https://cloud.ibm.com/docs/services/text-to-speech?topic=text-to-speech-gettingStarted#getting-started-tutorial

Veuillez remplacer "{apikey}" par l'api Key et "{url}" par url. Vous trouvez url et l'apikey dans l'onglet manage de de l'appli text to speech de IBM cloud. 
